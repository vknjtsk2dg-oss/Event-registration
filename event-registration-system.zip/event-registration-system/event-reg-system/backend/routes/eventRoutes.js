const express = require('express');
const { body } = require('express-validator');
const {
  getEvents,
  getEventById,
  checkAvailability,
  searchEvents,
  createEvent,
  updateEvent,
  deleteEvent,
  getCategories,
} = require('../controllers/eventController');
const { protect, adminOnly, optionalAuth } = require('../middleware/auth');

const router = express.Router();

const eventValidation = [
  body('name').trim().notEmpty().withMessage('Event name is required'),
  body('description').trim().notEmpty().withMessage('Description is required'),
  body('category').trim().notEmpty().withMessage('Category is required'),
  body('date').notEmpty().withMessage('Date is required'),
  body('time').notEmpty().withMessage('Time is required'),
  body('venue').trim().notEmpty().withMessage('Venue is required'),
  body('totalSeats').isInt({ min: 1 }).withMessage('Total seats must be a positive number'),
];

router.get('/', getEvents);
router.get('/search/ai', optionalAuth, searchEvents);
router.get('/meta/categories', getCategories);
router.get('/:id', getEventById);
router.get('/:id/availability', checkAvailability);

router.post('/', protect, adminOnly, eventValidation, createEvent);
router.put('/:id', protect, adminOnly, updateEvent);
router.delete('/:id', protect, adminOnly, deleteEvent);

module.exports = router;
