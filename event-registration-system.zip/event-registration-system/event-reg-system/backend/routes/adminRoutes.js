const express = require('express');
const {
  getDashboardStats,
  getEventStats,
  getAllRegistrations,
  getAllUsers,
  updateUserStatus,
  deleteUser,
} = require('../controllers/adminController');
const { protect, adminOnly } = require('../middleware/auth');

const router = express.Router();

router.use(protect, adminOnly);

router.get('/stats', getDashboardStats);
router.get('/events/stats', getEventStats);
router.get('/registrations', getAllRegistrations);
router.get('/users', getAllUsers);
router.put('/users/:id/status', updateUserStatus);
router.delete('/users/:id', deleteUser);

module.exports = router;
