const express = require('express');
const { body } = require('express-validator');
const {
  registerForEvent,
  getRegistrationById,
  getMyRegistrations,
  cancelRegistration,
} = require('../controllers/registrationController');
const { protect } = require('../middleware/auth');

const router = express.Router();

const registrationValidation = [
  body('eventId').notEmpty().withMessage('Event is required'),
  body('fullName').trim().notEmpty().withMessage('Full name is required'),
  body('email').isEmail().withMessage('A valid email is required'),
  body('phone').trim().notEmpty().withMessage('Phone number is required'),
  body('college').trim().notEmpty().withMessage('College/Department is required'),
  body('studentId').trim().notEmpty().withMessage('Student ID is required'),
];

router.post('/', protect, registrationValidation, registerForEvent);
router.get('/my', protect, getMyRegistrations);
router.get('/:id', protect, getRegistrationById);
router.put('/:id/cancel', protect, cancelRegistration);

module.exports = router;
