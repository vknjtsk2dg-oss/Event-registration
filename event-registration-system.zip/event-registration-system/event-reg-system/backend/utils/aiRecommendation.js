/**
 * AI-Powered Event Recommendation Engine
 * ---------------------------------------
 * This module powers the "AI search" feature. It understands a free-text
 * query (or a list of selected interests) and ranks events by relevance
 * using weighted keyword matching, synonym/interest expansion, and
 * recency/availability boosts.
 *
 * It works fully offline with zero external dependencies or API keys.
 * If AI_PROVIDER + AI_API_KEY are set in .env, `getAIExplanation()` will
 * additionally call a real LLM (Anthropic or OpenAI) to generate a
 * natural-language explanation of the recommendations. This is optional -
 * the ranking itself never depends on the external call.
 */

const STOPWORDS = new Set([
  'a', 'an', 'the', 'i', 'am', 'is', 'are', 'was', 'were', 'be', 'been',
  'in', 'on', 'at', 'for', 'to', 'of', 'and', 'or', 'with', 'about',
  'interested', 'interest', 'interests', 'looking', 'want', 'need',
  'me', 'my', 'find', 'show', 'search', 'events', 'event', 'related',
  'something', 'like', 'related', 'please', 'can', 'you', 'do', 'have',
]);

// Domain knowledge: maps a concept to related words commonly used on campus
// event listings. This is what lets a search for "coding and AI" surface
// events titled "Hackathon" or "GenAI Workshop" even without exact word match.
const SYNONYMS = {
  coding: ['programming', 'developer', 'hackathon', 'software', 'code', 'coder', 'dev', 'app development', 'web development'],
  programming: ['coding', 'developer', 'hackathon', 'software', 'code'],
  ai: ['artificial intelligence', 'machine learning', 'ml', 'deep learning', 'neural network', 'genai', 'generative ai', 'chatbot', 'llm', 'gpt'],
  'artificial intelligence': ['ai', 'machine learning', 'ml', 'deep learning', 'neural network'],
  'machine learning': ['ai', 'ml', 'deep learning', 'data science', 'neural network'],
  ml: ['machine learning', 'ai', 'data science'],
  hackathon: ['coding', 'programming', 'competition', 'build', 'develop'],
  data: ['data science', 'analytics', 'statistics', 'big data', 'data visualization'],
  design: ['ux', 'ui', 'graphic design', 'creative', 'art', 'visual'],
  music: ['concert', 'band', 'singing', 'instrumental', 'dj', 'performance'],
  dance: ['performance', 'choreography', 'cultural', 'competition'],
  sports: ['tournament', 'athletics', 'fitness', 'match', 'game', 'cricket', 'football', 'basketball'],
  business: ['entrepreneurship', 'startup', 'finance', 'marketing', 'management', 'pitch'],
  entrepreneurship: ['startup', 'business', 'pitch', 'venture', 'innovation'],
  robotics: ['engineering', 'automation', 'ai', 'electronics', 'mechatronics'],
  gaming: ['esports', 'video games', 'tournament', 'competition'],
  literature: ['writing', 'poetry', 'debate', 'book', 'reading', 'quiz'],
  art: ['design', 'painting', 'exhibition', 'creative', 'craft'],
  career: ['placement', 'job', 'internship', 'resume', 'networking', 'recruitment'],
  workshop: ['training', 'hands-on', 'session', 'bootcamp', 'seminar'],
  seminar: ['workshop', 'lecture', 'talk', 'session', 'webinar'],
  cultural: ['fest', 'festival', 'tradition', 'dance', 'music'],
  science: ['research', 'innovation', 'technology', 'stem', 'exhibition'],
};

function normalize(text) {
  return (text || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function tokenize(text) {
  return normalize(text)
    .split(' ')
    .filter((w) => w.length > 1 && !STOPWORDS.has(w));
}

// Expands a set of query terms with domain synonyms so the search
// "understands" intent rather than requiring exact keyword matches.
function expandTerms(terms) {
  const expanded = new Set(terms);
  terms.forEach((term) => {
    if (SYNONYMS[term]) {
      SYNONYMS[term].forEach((syn) => {
        tokenize(syn).forEach((t) => expanded.add(t));
        expanded.add(syn);
      });
    }
    // also check multi-word synonym keys that contain this term
    Object.keys(SYNONYMS).forEach((key) => {
      if (key.includes(term) && key !== term) {
        expanded.add(key);
      }
    });
  });
  return Array.from(expanded);
}

function fieldScore(fieldText, expandedTerms, weight) {
  const fieldTokens = new Set(tokenize(fieldText));
  const fieldNormalized = normalize(fieldText);
  let score = 0;
  let matched = [];

  expandedTerms.forEach((term) => {
    const termNorm = normalize(term);
    if (!termNorm) return;
    if (termNorm.includes(' ')) {
      // multi-word phrase match against the raw normalized field text
      if (fieldNormalized.includes(termNorm)) {
        score += weight * 1.5;
        matched.push(term);
      }
    } else if (fieldTokens.has(termNorm)) {
      score += weight;
      matched.push(term);
    }
  });

  return { score, matched };
}

/**
 * Ranks events against a free-text query and/or a list of user interests.
 * @param {Array} events - array of event documents (plain objects)
 * @param {String} query - free text search, e.g. "I am interested in coding and AI"
 * @param {Array<String>} interests - optional list of interest tags from the user's profile
 * @returns {Array} events sorted by relevance, each annotated with `matchScore` and `matchReasons`
 */
function recommendEvents(events, query = '', interests = []) {
  const baseTerms = [
    ...tokenize(query),
    ...interests.flatMap((i) => tokenize(i)),
  ];

  const hasQuery = baseTerms.length > 0;
  const expandedTerms = hasQuery ? expandTerms(baseTerms) : [];

  const now = new Date();

  const scored = events.map((eventDoc) => {
    const event = eventDoc.toObject ? eventDoc.toObject() : eventDoc;

    let score = 0;
    let matched = new Set();

    if (hasQuery) {
      const nameResult = fieldScore(event.name, expandedTerms, 5);
      const categoryResult = fieldScore(event.category, expandedTerms, 4);
      const tagsResult = fieldScore((event.tags || []).join(' '), expandedTerms, 4);
      const descResult = fieldScore(event.description, expandedTerms, 2);

      score += nameResult.score + categoryResult.score + tagsResult.score + descResult.score;
      [...nameResult.matched, ...categoryResult.matched, ...tagsResult.matched, ...descResult.matched]
        .forEach((m) => matched.add(m));
    }

    // Recency boost: events happening sooner (but still upcoming) rank slightly higher
    const eventDate = new Date(event.date);
    const daysAway = (eventDate - now) / (1000 * 60 * 60 * 24);
    let recencyBoost = 0;
    if (daysAway >= 0 && daysAway <= 30) {
      recencyBoost = (30 - daysAway) / 30; // 0..1
    }

    // Availability boost: don't recommend full events as strongly
    const availabilityBoost = event.availableSeats > 0 ? 0.5 : -2;

    const finalScore = score + recencyBoost * (hasQuery ? 0.5 : 3) + availabilityBoost;

    return {
      ...event,
      matchScore: Math.round(finalScore * 100) / 100,
      matchReasons: Array.from(matched).slice(0, 5),
    };
  });

  // If there was a real query, only keep events with some positive relevance
  // (or fall back to showing everything sorted by recency if nothing matched at all).
  let results = scored;
  if (hasQuery) {
    const relevant = scored.filter((e) => e.matchScore > 0);
    results = relevant.length > 0 ? relevant : scored;
  }

  results.sort((a, b) => b.matchScore - a.matchScore);
  return results;
}

/**
 * Optional: produce a short natural-language explanation of why these
 * events were recommended. Uses a real LLM if AI_PROVIDER/AI_API_KEY are
 * configured; otherwise falls back to a deterministic local summary so the
 * feature always works without any external dependency.
 */
async function getAIExplanation(query, topEvents) {
  const provider = process.env.AI_PROVIDER;
  const apiKey = process.env.AI_API_KEY;

  if (provider && apiKey && topEvents.length > 0) {
    try {
      return await callExternalLLM(provider, apiKey, query, topEvents);
    } catch (err) {
      console.warn('External AI provider call failed, falling back to local summary:', err.message);
    }
  }

  return localExplanation(query, topEvents);
}

function localExplanation(query, topEvents) {
  if (!topEvents || topEvents.length === 0) {
    return query
      ? `No close matches found for "${query}". Showing all upcoming events instead.`
      : 'Showing all upcoming events.';
  }
  const names = topEvents.slice(0, 4).map((e) => e.name).join(', ');
  return query
    ? `Based on "${query}", the best matches are: ${names}.`
    : `Recommended for you: ${names}.`;
}

async function callExternalLLM(provider, apiKey, query, topEvents) {
  const eventSummaries = topEvents
    .slice(0, 6)
    .map((e, i) => `${i + 1}. ${e.name} (${e.category}) - ${e.description}`)
    .join('\n');

  const prompt = `A student searched for events with this query: "${query}".\nHere are the top matching campus events:\n${eventSummaries}\n\nIn 1-2 sentences, explain why these events fit the student's interests. Be warm and concise.`;

  if (provider === 'anthropic') {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 200,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    const data = await res.json();
    const text = data?.content?.find((c) => c.type === 'text')?.text;
    return text || localExplanation(query, topEvents);
  }

  if (provider === 'openai') {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        max_tokens: 200,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    const data = await res.json();
    return data?.choices?.[0]?.message?.content || localExplanation(query, topEvents);
  }

  return localExplanation(query, topEvents);
}

module.exports = { recommendEvents, getAIExplanation, tokenize };
