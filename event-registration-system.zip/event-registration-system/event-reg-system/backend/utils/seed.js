/**
 * Seed script - populates the database with an admin account and sample
 * campus events so the app is usable immediately after setup.
 * Run with: npm run seed
 */
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Admin = require('../models/Admin');
const Event = require('../models/Event');
const Registration = require('../models/Registration');

const sampleEvents = [
  {
    name: 'AI Workshop: Build Your First Neural Network',
    description:
      'A hands-on workshop covering the fundamentals of artificial intelligence and machine learning. Participants will build and train a simple neural network using Python.',
    category: 'Technology',
    tags: ['ai', 'machine learning', 'python', 'neural networks', 'workshop'],
    date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    time: '10:00 AM',
    venue: 'Computer Science Auditorium',
    totalSeats: 60,
    availableSeats: 60,
    imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800',
    organizer: 'AI & ML Club',
  },
  {
    name: '48-Hour Coding Hackathon',
    description:
      'Team up and build an innovative software project in 48 hours. Open to all skill levels. Mentors, free food, and great prizes for the winning teams.',
    category: 'Technology',
    tags: ['coding', 'hackathon', 'programming', 'software development'],
    date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
    time: '9:00 AM',
    venue: 'Innovation Lab, Block C',
    totalSeats: 120,
    availableSeats: 120,
    imageUrl: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800',
    organizer: 'Developer Student Club',
  },
  {
    name: 'Machine Learning Seminar Series',
    description:
      'Industry experts discuss real-world applications of machine learning in healthcare, finance, and autonomous systems, followed by a Q&A session.',
    category: 'Technology',
    tags: ['machine learning', 'ai', 'data science', 'seminar'],
    date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
    time: '2:00 PM',
    venue: 'Main Seminar Hall',
    totalSeats: 100,
    availableSeats: 40,
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800',
    organizer: 'Department of Computer Science',
  },
  {
    name: 'GenAI Workshop: Prompt Engineering & LLM Apps',
    description:
      'Learn how generative AI and large language models work, and build a simple GenAI-powered application by the end of the session.',
    category: 'Technology',
    tags: ['genai', 'llm', 'ai', 'chatbot', 'prompt engineering'],
    date: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000),
    time: '11:00 AM',
    venue: 'Room 204, Tech Building',
    totalSeats: 50,
    availableSeats: 50,
    imageUrl: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800',
    organizer: 'AI & ML Club',
  },
  {
    name: 'Campus Cultural Fest: Rhythms',
    description:
      'An evening of music, dance, and cultural performances by student groups from across the campus. Open to all students and families.',
    category: 'Cultural',
    tags: ['music', 'dance', 'cultural', 'performance', 'festival'],
    date: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000),
    time: '6:00 PM',
    venue: 'Open Air Amphitheatre',
    totalSeats: 500,
    availableSeats: 500,
    imageUrl: 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800',
    organizer: 'Cultural Committee',
  },
  {
    name: 'Inter-College Basketball Tournament',
    description:
      'Cheer for your college team in the annual inter-college basketball championship. Finals followed by a prize distribution ceremony.',
    category: 'Sports',
    tags: ['sports', 'basketball', 'tournament', 'competition'],
    date: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000),
    time: '4:00 PM',
    venue: 'University Sports Complex',
    totalSeats: 300,
    availableSeats: 5,
    imageUrl: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=800',
    organizer: 'Sports Board',
  },
  {
    name: 'Startup Pitch Day',
    description:
      'Student entrepreneurs pitch their startup ideas to a panel of investors and alumni. Networking session and refreshments follow.',
    category: 'Business',
    tags: ['business', 'entrepreneurship', 'startup', 'pitch', 'networking'],
    date: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000),
    time: '3:00 PM',
    venue: 'Business School Auditorium',
    totalSeats: 80,
    availableSeats: 0,
    imageUrl: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800',
    organizer: 'E-Cell',
  },
  {
    name: 'Robotics Expo & Showcase',
    description:
      'Explore student-built robots and automation projects. Live demonstrations, robot battles, and an open build session.',
    category: 'Technology',
    tags: ['robotics', 'engineering', 'automation', 'electronics'],
    date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    time: '10:30 AM',
    venue: 'Engineering Block Courtyard',
    totalSeats: 150,
    availableSeats: 150,
    imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800',
    organizer: 'Robotics Club',
  },
];

const seed = async () => {
  await connectDB();

  console.log('Clearing existing data...');
  await Promise.all([
    User.deleteMany({ role: 'admin' }),
    Admin.deleteMany({}),
    Event.deleteMany({}),
  ]);

  console.log('Creating admin account...');
  const admin = await User.create({
    fullName: process.env.ADMIN_NAME || 'Super Admin',
    email: process.env.ADMIN_EMAIL || 'admin@campus.edu',
    password: process.env.ADMIN_PASSWORD || 'Admin@12345',
    role: 'admin',
  });
  await Admin.create({ user: admin._id });

  console.log('Creating sample events...');
  await Event.insertMany(sampleEvents.map((e) => ({ ...e, createdBy: admin._id })));

  console.log('\nSeed complete!');
  console.log(`Admin login -> email: ${admin.email} / password: ${process.env.ADMIN_PASSWORD || 'Admin@12345'}`);
  console.log(`Created ${sampleEvents.length} sample events.`);

  await mongoose.connection.close();
  process.exit(0);
};

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
