const asyncHandler = require('express-async-handler');
const { validationResult } = require('express-validator');
const { customAlphabet } = require('nanoid');
const Event = require('../models/Event');
const Registration = require('../models/Registration');

const nanoid = customAlphabet('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 8);
const generateRegistrationId = () => `REG-${nanoid()}`;

// @desc    Register the logged-in user for an event
// @route   POST /api/registrations
// @access  Private
const registerForEvent = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400);
    throw new Error(errors.array()[0].msg);
  }

  const { eventId, fullName, email, phone, college, department, studentId } = req.body;

  const event = await Event.findById(eventId);
  if (!event) {
    res.status(404);
    throw new Error('Event not found');
  }

  if (event.status === 'cancelled' || event.status === 'completed') {
    res.status(400);
    throw new Error(`Registration closed. This event is ${event.status}.`);
  }

  // Prevent duplicate registration for the same event
  const existing = await Registration.findOne({
    user: req.user._id,
    event: eventId,
    status: 'confirmed',
  });
  if (existing) {
    res.status(400);
    throw new Error('You are already registered for this event');
  }

  // Atomically decrement available seats ONLY if a seat is still available.
  // This prevents a race condition where two simultaneous requests could
  // both pass a naive "if availableSeats > 0" check.
  const updatedEvent = await Event.findOneAndUpdate(
    { _id: eventId, availableSeats: { $gt: 0 } },
    { $inc: { availableSeats: -1 } },
    { new: true }
  );

  if (!updatedEvent) {
    res.status(400);
    throw new Error('Registration Closed - No Seats Available');
  }

  let registration;
  try {
    registration = await Registration.create({
      registrationId: generateRegistrationId(),
      user: req.user._id,
      event: eventId,
      fullName,
      email,
      phone,
      college,
      department,
      studentId,
      status: 'confirmed',
    });
  } catch (err) {
    // Roll back the seat decrement if registration creation fails
    // (e.g. a duplicate slipped through under concurrency).
    await Event.findByIdAndUpdate(eventId, { $inc: { availableSeats: 1 } });
    if (err.code === 11000) {
      res.status(400);
      throw new Error('You are already registered for this event');
    }
    throw err;
  }

  res.status(201).json({
    success: true,
    message: 'Registration Successful! Your seat has been confirmed.',
    registration,
    event: {
      _id: updatedEvent._id,
      name: updatedEvent.name,
      availableSeats: updatedEvent.availableSeats,
      totalSeats: updatedEvent.totalSeats,
    },
  });
});

// @desc    Get a single registration (confirmation page / receipt)
// @route   GET /api/registrations/:id
// @access  Private
const getRegistrationById = asyncHandler(async (req, res) => {
  const registration = await Registration.findById(req.params.id).populate(
    'event',
    'name date time venue category imageUrl'
  );

  if (!registration) {
    res.status(404);
    throw new Error('Registration not found');
  }

  if (
    registration.user.toString() !== req.user._id.toString() &&
    req.user.role !== 'admin'
  ) {
    res.status(403);
    throw new Error('Not authorized to view this registration');
  }

  res.json({ success: true, registration });
});

// @desc    Get the logged-in user's registration history
// @route   GET /api/registrations/my
// @access  Private
const getMyRegistrations = asyncHandler(async (req, res) => {
  const registrations = await Registration.find({ user: req.user._id })
    .populate('event', 'name date time venue category imageUrl status availableSeats totalSeats')
    .sort({ createdAt: -1 });

  res.json({ success: true, count: registrations.length, registrations });
});

// @desc    Cancel a registration (restores the seat)
// @route   PUT /api/registrations/:id/cancel
// @access  Private
const cancelRegistration = asyncHandler(async (req, res) => {
  const registration = await Registration.findById(req.params.id);

  if (!registration) {
    res.status(404);
    throw new Error('Registration not found');
  }

  if (
    registration.user.toString() !== req.user._id.toString() &&
    req.user.role !== 'admin'
  ) {
    res.status(403);
    throw new Error('Not authorized to cancel this registration');
  }

  if (registration.status === 'cancelled') {
    res.status(400);
    throw new Error('This registration is already cancelled');
  }

  registration.status = 'cancelled';
  registration.cancelledAt = new Date();
  await registration.save();

  // Free up the seat
  await Event.findByIdAndUpdate(registration.event, { $inc: { availableSeats: 1 } });

  res.json({ success: true, message: 'Registration cancelled successfully', registration });
});

module.exports = {
  registerForEvent,
  getRegistrationById,
  getMyRegistrations,
  cancelRegistration,
};
