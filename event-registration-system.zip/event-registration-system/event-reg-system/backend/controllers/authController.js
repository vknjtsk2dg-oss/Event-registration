const asyncHandler = require('express-async-handler');
const { validationResult } = require('express-validator');
const User = require('../models/User');
const generateToken = require('../utils/generateToken');

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
const registerUser = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400);
    throw new Error(errors.array()[0].msg);
  }

  const { fullName, email, password, phone, college, department, studentId, interests } = req.body;

  const existingUser = await User.findOne({ email: email.toLowerCase() });
  if (existingUser) {
    res.status(400);
    throw new Error('An account with this email already exists');
  }

  const user = await User.create({
    fullName,
    email,
    password,
    phone,
    college,
    department,
    studentId,
    interests: Array.isArray(interests) ? interests : [],
  });

  res.status(201).json({
    success: true,
    message: 'Registration successful',
    user: user.toSafeObject(),
    token: generateToken(user._id, user.role),
  });
});

// @desc    Login user or admin
// @route   POST /api/auth/login
// @access  Public
const loginUser = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400);
    throw new Error(errors.array()[0].msg);
  }

  const { email, password } = req.body;

  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user || !(await user.matchPassword(password))) {
    res.status(401);
    throw new Error('Invalid email or password');
  }

  if (!user.isActive) {
    res.status(403);
    throw new Error('This account has been deactivated. Please contact the admin.');
  }

  res.json({
    success: true,
    message: 'Login successful',
    user: user.toSafeObject(),
    token: generateToken(user._id, user.role),
  });
});

// @desc    Get current logged-in user's profile
// @route   GET /api/auth/profile
// @access  Private
const getProfile = asyncHandler(async (req, res) => {
  res.json({ success: true, user: req.user.toSafeObject() });
});

// @desc    Update current logged-in user's profile
// @route   PUT /api/auth/profile
// @access  Private
const updateProfile = asyncHandler(async (req, res) => {
  const fields = ['fullName', 'phone', 'college', 'department', 'studentId', 'interests'];
  fields.forEach((field) => {
    if (req.body[field] !== undefined) {
      req.user[field] = req.body[field];
    }
  });

  if (req.body.password) {
    if (req.body.password.length < 6) {
      res.status(400);
      throw new Error('Password must be at least 6 characters long');
    }
    req.user.password = req.body.password;
  }

  const updated = await req.user.save();
  res.json({ success: true, message: 'Profile updated', user: updated.toSafeObject() });
});

module.exports = { registerUser, loginUser, getProfile, updateProfile };
