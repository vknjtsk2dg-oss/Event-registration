const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const Event = require('../models/Event');
const Registration = require('../models/Registration');

// @desc    Dashboard summary stats
// @route   GET /api/admin/stats
// @access  Private/Admin
const getDashboardStats = asyncHandler(async (req, res) => {
  const [totalUsers, totalEvents, totalRegistrations, activeRegistrations] = await Promise.all([
    User.countDocuments({ role: 'user' }),
    Event.countDocuments(),
    Registration.countDocuments(),
    Registration.countDocuments({ status: 'confirmed' }),
  ]);

  const seatAgg = await Event.aggregate([
    {
      $group: {
        _id: null,
        totalSeats: { $sum: '$totalSeats' },
        availableSeats: { $sum: '$availableSeats' },
      },
    },
  ]);

  const seatStats = seatAgg[0] || { totalSeats: 0, availableSeats: 0 };

  const upcomingEventsCount = await Event.countDocuments({
    date: { $gte: new Date() },
    status: { $ne: 'cancelled' },
  });

  res.json({
    success: true,
    stats: {
      totalUsers,
      totalEvents,
      upcomingEventsCount,
      totalRegistrations,
      activeRegistrations,
      cancelledRegistrations: totalRegistrations - activeRegistrations,
      totalSeats: seatStats.totalSeats,
      availableSeats: seatStats.availableSeats,
      occupiedSeats: seatStats.totalSeats - seatStats.availableSeats,
    },
  });
});

// @desc    Event-wise registration statistics
// @route   GET /api/admin/events/stats
// @access  Private/Admin
const getEventStats = asyncHandler(async (req, res) => {
  const events = await Event.find().sort({ date: 1 });

  const stats = await Promise.all(
    events.map(async (event) => {
      const [confirmed, cancelled] = await Promise.all([
        Registration.countDocuments({ event: event._id, status: 'confirmed' }),
        Registration.countDocuments({ event: event._id, status: 'cancelled' }),
      ]);
      return {
        eventId: event._id,
        name: event.name,
        category: event.category,
        date: event.date,
        totalSeats: event.totalSeats,
        availableSeats: event.availableSeats,
        occupiedSeats: event.totalSeats - event.availableSeats,
        confirmedRegistrations: confirmed,
        cancelledRegistrations: cancelled,
        fillRate: event.totalSeats > 0
          ? Math.round(((event.totalSeats - event.availableSeats) / event.totalSeats) * 100)
          : 0,
      };
    })
  );

  res.json({ success: true, stats });
});

// @desc    View all registrations (with optional event filter)
// @route   GET /api/admin/registrations
// @access  Private/Admin
const getAllRegistrations = asyncHandler(async (req, res) => {
  const { eventId, status } = req.query;
  const filter = {};
  if (eventId) filter.event = eventId;
  if (status) filter.status = status;

  const registrations = await Registration.find(filter)
    .populate('event', 'name date time venue')
    .populate('user', 'fullName email')
    .sort({ createdAt: -1 });

  res.json({ success: true, count: registrations.length, registrations });
});

// @desc    Get all users (for admin user management)
// @route   GET /api/admin/users
// @access  Private/Admin
const getAllUsers = asyncHandler(async (req, res) => {
  const users = await User.find({ role: 'user' }).sort({ createdAt: -1 });
  res.json({ success: true, count: users.length, users });
});

// @desc    Activate / deactivate a user account
// @route   PUT /api/admin/users/:id/status
// @access  Private/Admin
const updateUserStatus = asyncHandler(async (req, res) => {
  const { isActive } = req.body;
  const user = await User.findById(req.params.id);

  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  if (user.role === 'admin') {
    res.status(400);
    throw new Error('Cannot modify another admin account here');
  }

  user.isActive = !!isActive;
  await user.save();

  res.json({ success: true, message: `User ${isActive ? 'activated' : 'deactivated'}`, user: user.toSafeObject() });
});

// @desc    Delete a user account
// @route   DELETE /api/admin/users/:id
// @access  Private/Admin
const deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  if (user.role === 'admin') {
    res.status(400);
    throw new Error('Cannot delete an admin account here');
  }

  // Release seats held by this user's active registrations
  const activeRegs = await Registration.find({ user: user._id, status: 'confirmed' });
  await Promise.all(
    activeRegs.map((r) => Event.findByIdAndUpdate(r.event, { $inc: { availableSeats: 1 } }))
  );
  await Registration.deleteMany({ user: user._id });
  await user.deleteOne();

  res.json({ success: true, message: 'User and their registrations removed' });
});

module.exports = {
  getDashboardStats,
  getEventStats,
  getAllRegistrations,
  getAllUsers,
  updateUserStatus,
  deleteUser,
};
