const asyncHandler = require('express-async-handler');
const { validationResult } = require('express-validator');
const Event = require('../models/Event');
const Registration = require('../models/Registration');
const { recommendEvents } = require('../utils/aiRecommendation');

// @desc    Get all events (supports plain filtering: category, status, date range)
// @route   GET /api/events
// @access  Public
const getEvents = asyncHandler(async (req, res) => {
  const { category, status, upcoming } = req.query;
  const filter = {};

  if (category && category !== 'all') filter.category = category;
  if (status && status !== 'all') filter.status = status;
  if (upcoming === 'true') filter.date = { $gte: new Date() };

  const events = await Event.find(filter).sort({ date: 1 });
  res.json({ success: true, count: events.length, events });
});

// @desc    Get single event by id
// @route   GET /api/events/:id
// @access  Public
const getEventById = asyncHandler(async (req, res) => {
  const event = await Event.findById(req.params.id);
  if (!event) {
    res.status(404);
    throw new Error('Event not found');
  }
  res.json({ success: true, event });
});

// @desc    Check seat availability for an event (used before showing/submitting registration form)
// @route   GET /api/events/:id/availability
// @access  Public
const checkAvailability = asyncHandler(async (req, res) => {
  const event = await Event.findById(req.params.id).select('name totalSeats availableSeats status date');
  if (!event) {
    res.status(404);
    throw new Error('Event not found');
  }

  const isAvailable = event.availableSeats > 0 && event.status !== 'cancelled' && event.status !== 'completed';

  res.json({
    success: true,
    eventId: event._id,
    eventName: event.name,
    totalSeats: event.totalSeats,
    availableSeats: event.availableSeats,
    occupiedSeats: event.totalSeats - event.availableSeats,
    isAvailable,
    reason: isAvailable
      ? null
      : event.availableSeats <= 0
      ? 'No seats available. Registration closed.'
      : `Event is ${event.status}.`,
  });
});

// @desc    AI-powered / keyword event search & recommendations
// @route   GET /api/events/search/ai?q=coding+and+ai
// @access  Public
const searchEvents = asyncHandler(async (req, res) => {
  const { q = '', category, includeExplanation } = req.query;

  const filter = {};
  if (category && category !== 'all') filter.category = category;

  const events = await Event.find(filter);
  const interests = req.user?.interests || [];

  const ranked = recommendEvents(events, q, interests);

  let explanation = null;
  if (includeExplanation === 'true') {
    const { getAIExplanation } = require('../utils/aiRecommendation');
    explanation = await getAIExplanation(q, ranked);
  }

  res.json({
    success: true,
    query: q,
    count: ranked.length,
    events: ranked,
    explanation,
  });
});

// @desc    Create a new event
// @route   POST /api/events
// @access  Private/Admin
const createEvent = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400);
    throw new Error(errors.array()[0].msg);
  }

  const {
    name, description, category, tags, date, time, venue,
    totalSeats, imageUrl, organizer, status,
  } = req.body;

  const event = await Event.create({
    name,
    description,
    category,
    tags: Array.isArray(tags) ? tags : (tags ? String(tags).split(',').map((t) => t.trim()) : []),
    date,
    time,
    venue,
    totalSeats,
    availableSeats: totalSeats,
    imageUrl,
    organizer,
    status,
    createdBy: req.user._id,
  });

  res.status(201).json({ success: true, message: 'Event created successfully', event });
});

// @desc    Update an event
// @route   PUT /api/events/:id
// @access  Private/Admin
const updateEvent = asyncHandler(async (req, res) => {
  const event = await Event.findById(req.params.id);
  if (!event) {
    res.status(404);
    throw new Error('Event not found');
  }

  const editableFields = [
    'name', 'description', 'category', 'date', 'time', 'venue',
    'imageUrl', 'organizer', 'status',
  ];
  editableFields.forEach((field) => {
    if (req.body[field] !== undefined) event[field] = req.body[field];
  });

  if (req.body.tags !== undefined) {
    event.tags = Array.isArray(req.body.tags)
      ? req.body.tags
      : String(req.body.tags).split(',').map((t) => t.trim());
  }

  // If totalSeats changes, adjust availableSeats by the same delta so
  // existing registrations remain consistent.
  if (req.body.totalSeats !== undefined) {
    const newTotal = Number(req.body.totalSeats);
    if (newTotal < event.totalSeats - event.availableSeats) {
      res.status(400);
      throw new Error('Total seats cannot be less than the number of seats already occupied');
    }
    const occupied = event.totalSeats - event.availableSeats;
    event.totalSeats = newTotal;
    event.availableSeats = newTotal - occupied;
  }

  const updated = await event.save();
  res.json({ success: true, message: 'Event updated successfully', event: updated });
});

// @desc    Delete an event
// @route   DELETE /api/events/:id
// @access  Private/Admin
const deleteEvent = asyncHandler(async (req, res) => {
  const event = await Event.findById(req.params.id);
  if (!event) {
    res.status(404);
    throw new Error('Event not found');
  }

  await Registration.deleteMany({ event: event._id });
  await event.deleteOne();

  res.json({ success: true, message: 'Event and its registrations deleted successfully' });
});

// @desc    Get distinct event categories (for filter dropdowns)
// @route   GET /api/events/meta/categories
// @access  Public
const getCategories = asyncHandler(async (req, res) => {
  const categories = await Event.distinct('category');
  res.json({ success: true, categories });
});

module.exports = {
  getEvents,
  getEventById,
  checkAvailability,
  searchEvents,
  createEvent,
  updateEvent,
  deleteEvent,
  getCategories,
};
