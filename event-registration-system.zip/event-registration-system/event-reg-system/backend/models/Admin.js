const mongoose = require('mongoose');

/**
 * Admins are Users with role='admin' (so they share the same login/auth flow),
 * but we keep a dedicated Admin collection for admin-specific metadata and
 * an auditable record of admin actions, per the "Admins collection" requirement.
 */
const adminSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true,
    },
    permissions: {
      type: [String],
      default: ['manage_events', 'manage_registrations', 'manage_users'],
    },
    lastActionAt: {
      type: Date,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Admin', adminSchema);
