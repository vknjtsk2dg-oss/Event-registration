# EventHub — AI-Powered Campus Event Registration System

A full-stack MERN application for browsing, discovering (via an AI recommender),
and registering for campus events with live seat tracking.

```
event-reg-system/
├── backend/     Node.js + Express + MongoDB REST API (JWT auth, AI search, admin tools)
└── frontend/    React (CRA) single-page app
```

## Features

- **Auth**: JWT-based registration/login with bcrypt password hashing
- **AI-powered search & recommendations**: free-text queries like *"I am interested in
  coding and AI"* are matched against event name/category/tags/description using a
  synonym-aware scoring engine (`backend/utils/aiRecommendation.js`) — works fully
  offline, with an optional hook to call a real LLM (Anthropic/OpenAI) for a
  natural-language explanation if you set `AI_PROVIDER` + `AI_API_KEY`
- **Real-time seat availability**: checked from the database before the registration
  form is shown *and* re-checked immediately before it's submitted
- **Atomic seat booking**: seats are decremented with a single conditional
  `findOneAndUpdate` so two simultaneous registrations can never both take the
  last seat
- **Duplicate-registration prevention**: enforced both in application logic and with
  a partial unique index on `(user, event, status="confirmed")`
- **Cancellation**: releases the seat back to the pool immediately
- **Admin dashboard**: create/edit/delete events, view all registrations, manage
  users, and see event-wise fill-rate statistics
- **Responsive UI**: works down to mobile, with a distinct campus-navy / brass
  visual identity and a "digital event pass" ticket design used on the
  confirmation and My Registrations pages

## Tech stack

| Layer     | Tech |
|-----------|------|
| Frontend  | React 18, React Router 6, Axios |
| Backend   | Node.js, Express 4 |
| Database  | MongoDB + Mongoose |
| Auth      | JWT (jsonwebtoken) + bcryptjs |
| AI        | Local keyword/synonym recommender, optional Anthropic/OpenAI call for explanations |

---

## 1. Prerequisites

- Node.js 18+
- MongoDB running locally (`mongodb://127.0.0.1:27017`) or a MongoDB Atlas connection string

## 2. Backend setup

```bash
cd backend
cp .env.example .env    # then edit .env — at minimum set JWT_SECRET and MONGO_URI
npm install
npm run seed             # creates an admin account + sample events (optional but recommended)
npm run dev               # starts the API on http://localhost:5000 (nodemon)
```

Default seeded admin login (override in `.env` before seeding):
```
email:    admin@campus.edu
password: Admin@12345
```

### Key environment variables (`backend/.env`)

| Variable | Description |
|---|---|
| `PORT` | API port (default 5000) |
| `MONGO_URI` | MongoDB connection string |
| `JWT_SECRET` | Long random string used to sign tokens — **change this** |
| `JWT_EXPIRES_IN` | Token lifetime, e.g. `7d` |
| `CLIENT_URL` | Frontend origin, for CORS (default `http://localhost:3000`) |
| `AI_PROVIDER` / `AI_API_KEY` | Optional — enables an LLM-generated one-line explanation on top of the local recommender. Leave blank to use the built-in engine only. |

## 3. Frontend setup

```bash
cd frontend
npm install
npm start   # runs on http://localhost:3000, proxies /api to http://localhost:5000
```

Open http://localhost:3000 — the CRA dev server proxies API calls to the backend
automatically (see the `proxy` field in `frontend/package.json`), so no extra
config is needed in development.

## 4. Trying it out

1. Register a new account (or log in as the seeded admin) at `/register` or `/login`.
2. Browse `/events`, or go to `/search` and type something like
   *"I am interested in coding and AI"* — the AI recommender will surface the
   Hackathon, AI Workshop, ML Seminar, and GenAI Workshop first.
3. Open an event, check live seat availability, and click **Register**.
4. Fill in the registration form — you'll get a unique Registration ID and a
   digital event pass on the confirmation page.
5. View/cancel your registrations under **My Registrations**.
6. Log in as the admin (`/login`) and visit `/admin` to manage events,
   registrations, and users, and see event-wise fill-rate stats.

## 5. Registration flow (as implemented)

```
Login/Register → Browse or AI Search → Event Details (live seat check)
   → if seats available: Registration Form → Submit
        → server re-verifies seats atomically → seat count decremented
        → Registration Successful (unique Registration ID + digital pass)
   → if seats full: "Registration Closed — No Seats Available" (form is never shown)
```

## 6. API overview

| Method | Route | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create account |
| POST | `/api/auth/login` | Public | Log in |
| GET/PUT | `/api/auth/profile` | Private | View/update profile |
| GET | `/api/events` | Public | List events (filter by category/status) |
| GET | `/api/events/:id` | Public | Event details |
| GET | `/api/events/:id/availability` | Public | Live seat check |
| GET | `/api/events/search/ai?q=...` | Public | AI-powered search/recommendations |
| POST/PUT/DELETE | `/api/events` | Admin | Manage events |
| POST | `/api/registrations` | Private | Register for an event |
| GET | `/api/registrations/my` | Private | My registration history |
| PUT | `/api/registrations/:id/cancel` | Private | Cancel a registration |
| GET | `/api/admin/stats` | Admin | Dashboard summary stats |
| GET | `/api/admin/events/stats` | Admin | Event-wise registration stats |
| GET | `/api/admin/registrations` | Admin | All registrations |
| GET/PUT/DELETE | `/api/admin/users` | Admin | User management |

## 7. Notes on the AI recommendation engine

`backend/utils/aiRecommendation.js` tokenizes the search query, expands it with a
built-in synonym map (e.g. "coding" → programming, hackathon, developer…),
and scores every event on name/category/tags/description overlap, with small
boosts for events happening soon and events that still have open seats. This
means it works immediately, with no API key or external cost, and degrades
gracefully — if nothing matches well, it still returns the full event list
sorted sensibly rather than an empty page.

If you want smarter, model-generated explanations of *why* something was
recommended, set `AI_PROVIDER=anthropic` (or `openai`) and `AI_API_KEY` in
`backend/.env` — the ranking logic itself never depends on this, only the
optional one-line "AI insight" summary shown on the search page.
