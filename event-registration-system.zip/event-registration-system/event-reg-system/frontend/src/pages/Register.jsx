import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Auth.css';

const INTEREST_OPTIONS = ['Coding', 'AI', 'Design', 'Music', 'Sports', 'Business', 'Robotics', 'Cultural'];

const Register = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: '', email: '', password: '', phone: '', college: '', department: '', studentId: '',
  });
  const [interests, setInterests] = useState([]);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const toggleInterest = (interest) => {
    setInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const user = await register({ ...form, interests });
      navigate(user.role === 'admin' ? '/admin' : '/dashboard', { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="card auth-card" style={{ maxWidth: 560 }}>
        <h1>Create your account</h1>
        <p className="auth-sub">Register once, then check out and register for events in seconds.</p>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label" htmlFor="fullName">Full name</label>
            <input id="fullName" name="fullName" className="form-input" required
              placeholder="Jordan Lee" value={form.fullName} onChange={handleChange} />
          </div>

          <div className="auth-row">
            <div className="form-group">
              <label className="form-label" htmlFor="email">Email address</label>
              <input id="email" name="email" type="email" className="form-input" required
                placeholder="you@campus.edu" value={form.email} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label className="form-label" htmlFor="password">Password</label>
              <input id="password" name="password" type="password" className="form-input" required
                minLength={6} placeholder="At least 6 characters" value={form.password} onChange={handleChange} />
            </div>
          </div>

          <div className="auth-row">
            <div className="form-group">
              <label className="form-label" htmlFor="phone">Phone number</label>
              <input id="phone" name="phone" className="form-input"
                placeholder="+1 555 000 1234" value={form.phone} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label className="form-label" htmlFor="studentId">Student ID</label>
              <input id="studentId" name="studentId" className="form-input"
                placeholder="STU-00123" value={form.studentId} onChange={handleChange} />
            </div>
          </div>

          <div className="auth-row">
            <div className="form-group">
              <label className="form-label" htmlFor="college">College</label>
              <input id="college" name="college" className="form-input"
                placeholder="College of Engineering" value={form.college} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label className="form-label" htmlFor="department">Department</label>
              <input id="department" name="department" className="form-input"
                placeholder="Computer Science" value={form.department} onChange={handleChange} />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Your interests (helps the AI recommend events)</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {INTEREST_OPTIONS.map((interest) => (
                <button
                  type="button"
                  key={interest}
                  onClick={() => toggleInterest(interest)}
                  className="btn btn-sm"
                  style={{
                    background: interests.includes(interest) ? 'var(--violet)' : 'var(--surface-alt)',
                    color: interests.includes(interest) ? '#fff' : 'var(--text)',
                    border: '1px solid var(--line)',
                  }}
                >
                  {interest}
                </button>
              ))}
            </div>
          </div>

          <button type="submit" className="btn btn-primary btn-block" disabled={submitting}>
            {submitting ? 'Creating account…' : 'Create account'}
          </button>
        </form>

        <div className="auth-footer">
          Already have an account? <Link to="/login">Log in</Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
