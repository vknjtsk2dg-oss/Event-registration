import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import registrationService from '../services/registrationService';
import TicketCard from '../components/TicketCard';
import Loader from '../components/Loader';

const Confirmation = () => {
  const { id } = useParams();
  const [registration, setRegistration] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    registrationService
      .getRegistrationById(id)
      .then((data) => setRegistration(data.registration))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <Loader fullPage label="Fetching your confirmation…" />;

  if (error || !registration) {
    return (
      <div className="container listing-page">
        <div className="alert alert-error">{error || 'Registration not found.'}</div>
      </div>
    );
  }

  return (
    <div className="container" style={{ padding: '64px 24px 90px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <div style={{
        width: 64, height: 64, borderRadius: '50%', background: 'var(--teal-light)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.8rem', marginBottom: 20,
      }}>
        ✅
      </div>
      <h1 style={{ textAlign: 'center' }}>Registration Successful!</h1>
      <p style={{ textAlign: 'center', maxWidth: 460 }}>
        Your seat has been confirmed. Save your registration ID below — you'll need it if you contact
        the event organizers.
      </p>

      <div style={{ margin: '28px 0' }}>
        <TicketCard registration={registration} event={registration.event} status={registration.status} />
      </div>

      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', justifyContent: 'center' }}>
        <Link to="/my-registrations" className="btn btn-primary">View my registrations</Link>
        <Link to="/events" className="btn btn-outline">Browse more events</Link>
      </div>
    </div>
  );
};

export default Confirmation;
