import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import registrationService from '../services/registrationService';
import TicketCard from '../components/TicketCard';
import Loader from '../components/Loader';
import './MyRegistrations.css';

const MyRegistrations = () => {
  const [registrations, setRegistrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('confirmed');
  const [cancellingId, setCancellingId] = useState(null);

  const load = () => {
    setLoading(true);
    registrationService
      .getMyRegistrations()
      .then((data) => setRegistrations(data.registrations))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleCancel = async (regId) => {
    if (!window.confirm('Cancel this registration? Your seat will be released.')) return;
    setCancellingId(regId);
    try {
      await registrationService.cancelRegistration(regId);
      load();
    } catch (err) {
      alert(err.message);
    } finally {
      setCancellingId(null);
    }
  };

  const filtered = registrations.filter((r) => filter === 'all' || r.status === filter);

  return (
    <div className="container listing-page">
      <div className="listing-head">
        <div>
          <span className="section-eyebrow">Your passes</span>
          <h1>My Registrations</h1>
        </div>
        <Link to="/events" className="btn btn-outline">Browse events</Link>
      </div>

      <div className="listing-filters">
        {['confirmed', 'cancelled', 'all'].map((f) => (
          <button
            key={f}
            className="btn btn-sm"
            onClick={() => setFilter(f)}
            style={{
              background: filter === f ? 'var(--ink)' : 'var(--surface-alt)',
              color: filter === f ? '#fff' : 'var(--text)',
            }}
          >
            {f[0].toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {loading ? (
        <Loader />
      ) : error ? (
        <div className="alert alert-error">{error}</div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          {filter === 'confirmed' ? "You haven't registered for any events yet." : 'Nothing here.'}
          {' '}<Link to="/events">Browse events</Link>
        </div>
      ) : (
        <div className="my-regs-list">
          {filtered.map((reg) => (
            <div key={reg._id} className="my-regs-item">
              <TicketCard registration={reg} event={reg.event} status={reg.status} />
              <div className="my-regs-actions">
                <Link to={`/events/${reg.event?._id}`} className="btn btn-outline btn-sm">View event</Link>
                {reg.status === 'confirmed' && (
                  <button
                    className="btn btn-danger btn-sm"
                    disabled={cancellingId === reg._id}
                    onClick={() => handleCancel(reg._id)}
                  >
                    {cancellingId === reg._id ? 'Cancelling…' : 'Cancel registration'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyRegistrations;
