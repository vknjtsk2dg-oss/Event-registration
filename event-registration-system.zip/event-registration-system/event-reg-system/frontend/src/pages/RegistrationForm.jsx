import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import eventService from '../services/eventService';
import registrationService from '../services/registrationService';
import { useAuth } from '../context/AuthContext';
import SeatBadge from '../components/SeatBadge';
import Loader from '../components/Loader';
import './RegistrationForm.css';

const RegistrationForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [event, setEvent] = useState(null);
  const [availability, setAvailability] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const [form, setForm] = useState({
    fullName: '', email: '', phone: '', college: '', department: '', studentId: '',
  });

  useEffect(() => {
    setLoading(true);
    Promise.all([eventService.getEventById(id), eventService.checkAvailability(id)])
      .then(([eventData, availData]) => {
        setEvent(eventData.event);
        setAvailability(availData);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (user) {
      setForm((f) => ({
        ...f,
        fullName: user.fullName || '',
        email: user.email || '',
        phone: user.phone || '',
        college: user.college || '',
        department: user.department || '',
        studentId: user.studentId || '',
      }));
    }
  }, [user]);

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Re-verify seats are still available right before submitting, since
    // availability can change between page load and submission.
    setSubmitting(true);
    try {
      const fresh = await eventService.checkAvailability(id);
      if (!fresh.isAvailable) {
        setAvailability(fresh);
        setError(fresh.reason || 'Registration Closed — No Seats Available');
        setSubmitting(false);
        return;
      }

      const data = await registrationService.registerForEvent({ eventId: id, ...form });
      navigate(`/confirmation/${data.registration._id}`, { replace: true });
    } catch (err) {
      setError(err.message);
      // Refresh availability in case the error was seat-related
      eventService.checkAvailability(id).then(setAvailability).catch(() => {});
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <Loader fullPage label="Preparing registration form…" />;
  if (!event) return null;

  if (!availability?.isAvailable) {
    return (
      <div className="container listing-page">
        <div className="card" style={{ maxWidth: 520, margin: '40px auto', padding: 32, textAlign: 'center' }}>
          <h2 style={{ color: 'var(--coral)' }}>Registration Closed</h2>
          <p>{availability?.reason || 'No seats available for this event.'}</p>
          <Link to={`/events/${id}`} className="btn btn-outline" style={{ marginTop: 8 }}>
            ← Back to event
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container listing-page">
      <div className="reg-form-layout">
        <form className="card reg-form" onSubmit={handleSubmit}>
          <span className="section-eyebrow">Registration form</span>
          <h1>{event.name}</h1>
          <p className="auth-sub">Confirm your details to reserve your seat.</p>

          {error && <div className="alert alert-error">{error}</div>}

          <div className="form-group">
            <label className="form-label" htmlFor="fullName">Full name</label>
            <input id="fullName" name="fullName" className="form-input" required
              value={form.fullName} onChange={handleChange} />
          </div>

          <div className="auth-row">
            <div className="form-group">
              <label className="form-label" htmlFor="email">Email</label>
              <input id="email" name="email" type="email" className="form-input" required
                value={form.email} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label className="form-label" htmlFor="phone">Phone number</label>
              <input id="phone" name="phone" className="form-input" required
                value={form.phone} onChange={handleChange} />
            </div>
          </div>

          <div className="auth-row">
            <div className="form-group">
              <label className="form-label" htmlFor="college">College / Department</label>
              <input id="college" name="college" className="form-input" required
                placeholder="College of Engineering" value={form.college} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label className="form-label" htmlFor="studentId">Student ID</label>
              <input id="studentId" name="studentId" className="form-input" required
                value={form.studentId} onChange={handleChange} />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="department">Department (optional)</label>
            <input id="department" name="department" className="form-input"
              value={form.department} onChange={handleChange} />
          </div>

          <div className="form-group">
            <label className="form-label">Selected event</label>
            <input className="form-input" disabled value={event.name} style={{ background: 'var(--surface-alt)' }} />
          </div>

          <button type="submit" className="btn btn-primary btn-block" disabled={submitting}>
            {submitting ? 'Confirming your seat…' : 'Confirm registration'}
          </button>
        </form>

        <aside className="card reg-form-sidebar">
          <img
            src={event.imageUrl}
            alt=""
            style={{ width: '100%', height: 140, objectFit: 'cover', borderRadius: 10, marginBottom: 16 }}
          />
          <h3 style={{ fontSize: '1.05rem' }}>{event.name}</h3>
          <p style={{ fontSize: '0.85rem' }}>
            {new Date(event.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })} · {event.time}
          </p>
          <p style={{ fontSize: '0.85rem' }}>📍 {event.venue}</p>
          <SeatBadge availableSeats={availability.availableSeats} totalSeats={event.totalSeats} />
        </aside>
      </div>
    </div>
  );
};

export default RegistrationForm;
