import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import eventService from '../services/eventService';
import { useAuth } from '../context/AuthContext';
import SeatBadge, { seatState } from '../components/SeatBadge';
import Loader from '../components/Loader';
import './EventDetails.css';

const formatDate = (dateStr) =>
  new Date(dateStr).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });

const EventDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  const [event, setEvent] = useState(null);
  const [availability, setAvailability] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    Promise.all([eventService.getEventById(id), eventService.checkAvailability(id)])
      .then(([eventData, availData]) => {
        setEvent(eventData.event);
        setAvailability(availData);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  const handleRegisterClick = () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: { pathname: `/events/${id}/register` } } });
      return;
    }
    navigate(`/events/${id}/register`);
  };

  if (loading) return <Loader fullPage label="Loading event details…" />;
  if (error) return <div className="container listing-page"><div className="alert alert-error">{error}</div></div>;
  if (!event) return null;

  const state = seatState(event.availableSeats, event.totalSeats);
  const isOpen = availability?.isAvailable;

  return (
    <div className="event-details">
      <div className="event-details__hero" style={{ backgroundImage: `url(${event.imageUrl || ''})` }}>
        <div className="event-details__hero-overlay" />
        <div className="container event-details__hero-content">
          <span className="badge" style={{ background: 'rgba(255,255,255,0.16)', color: '#fff' }}>{event.category}</span>
          <h1>{event.name}</h1>
          <div className="event-details__hero-meta">
            <span>📅 {formatDate(event.date)}</span>
            <span>🕐 {event.time}</span>
            <span>📍 {event.venue}</span>
          </div>
        </div>
      </div>

      <div className="container event-details__body">
        <div className="event-details__main">
          <h2>About this event</h2>
          <p className="event-details__desc">{event.description}</p>

          {event.tags && event.tags.length > 0 && (
            <div className="event-details__tags">
              {event.tags.map((tag) => (
                <span key={tag} className="event-details__tag">#{tag}</span>
              ))}
            </div>
          )}

          <div className="event-details__organizer">
            <span className="form-label">Organized by</span>
            <p style={{ margin: 0, color: 'var(--ink)', fontWeight: 500 }}>{event.organizer}</p>
          </div>
        </div>

        <aside className="event-details__sidebar card">
          <div className="event-details__seats-head">
            <span className="form-label">Seat availability</span>
            <SeatBadge availableSeats={event.availableSeats} totalSeats={event.totalSeats} />
          </div>

          <div className="event-details__seat-bar">
            <div
              className={`event-details__seat-bar-fill event-details__seat-bar-fill--${state}`}
              style={{ width: `${Math.max(4, ((event.totalSeats - event.availableSeats) / event.totalSeats) * 100)}%` }}
            />
          </div>
          <div className="event-details__seat-count">
            {event.totalSeats - event.availableSeats} / {event.totalSeats} seats filled
          </div>

          {isOpen ? (
            <button className="btn btn-primary btn-block" style={{ marginTop: 18 }} onClick={handleRegisterClick}>
              Register for this event
            </button>
          ) : (
            <div style={{ marginTop: 18 }}>
              <div className="alert alert-error" style={{ marginBottom: 0 }}>
                {availability?.reason || 'Registration Closed — No Seats Available'}
              </div>
            </div>
          )}

          {!isAuthenticated && isOpen && (
            <p className="form-hint" style={{ textAlign: 'center', marginTop: 10 }}>
              You'll need to log in first.
            </p>
          )}

          <Link to="/events" className="btn btn-outline btn-block" style={{ marginTop: 10 }}>
            ← Back to all events
          </Link>
        </aside>
      </div>
    </div>
  );
};

export default EventDetails;
