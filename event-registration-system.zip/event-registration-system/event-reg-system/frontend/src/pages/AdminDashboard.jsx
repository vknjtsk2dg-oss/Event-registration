import React, { useEffect, useState, useCallback } from 'react';
import adminService from '../services/adminService';
import eventService from '../services/eventService';
import AdminEventForm from '../components/AdminEventForm';
import Loader from '../components/Loader';
import './AdminDashboard.css';

const TABS = ['Overview', 'Events', 'Registrations', 'Users'];

const formatDate = (d) => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

const AdminDashboard = () => {
  const [tab, setTab] = useState('Overview');

  return (
    <div className="container listing-page">
      <span className="section-eyebrow">Admin</span>
      <h1>Event management dashboard</h1>

      <div className="admin-tabs">
        {TABS.map((t) => (
          <button key={t} className={`admin-tab ${tab === t ? 'admin-tab--active' : ''}`} onClick={() => setTab(t)}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'Overview' && <OverviewTab />}
      {tab === 'Events' && <EventsTab />}
      {tab === 'Registrations' && <RegistrationsTab />}
      {tab === 'Users' && <UsersTab />}
    </div>
  );
};

// ---------------- Overview ----------------
const OverviewTab = () => {
  const [stats, setStats] = useState(null);
  const [eventStats, setEventStats] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([adminService.getDashboardStats(), adminService.getEventStats()])
      .then(([s, es]) => {
        setStats(s.stats);
        setEventStats(es.stats);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader />;

  const cards = [
    ['Total users', stats.totalUsers],
    ['Total events', stats.totalEvents],
    ['Active registrations', stats.activeRegistrations],
    ['Cancelled registrations', stats.cancelledRegistrations],
    ['Seats occupied', `${stats.occupiedSeats} / ${stats.totalSeats}`],
    ['Upcoming events', stats.upcomingEventsCount],
  ];

  return (
    <div>
      <div className="admin-stat-grid">
        {cards.map(([label, value]) => (
          <div className="card admin-stat-card" key={label}>
            <span className="admin-stat-card__value">{value}</span>
            <span className="admin-stat-card__label">{label}</span>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: 24, marginTop: 24 }}>
        <h2 style={{ marginTop: 0 }}>Event-wise registration statistics</h2>
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Event</th><th>Date</th><th>Category</th><th>Confirmed</th><th>Cancelled</th>
                <th>Seats (filled/total)</th><th>Fill rate</th>
              </tr>
            </thead>
            <tbody>
              {eventStats.map((e) => (
                <tr key={e.eventId}>
                  <td>{e.name}</td>
                  <td>{formatDate(e.date)}</td>
                  <td>{e.category}</td>
                  <td>{e.confirmedRegistrations}</td>
                  <td>{e.cancelledRegistrations}</td>
                  <td>{e.occupiedSeats} / {e.totalSeats}</td>
                  <td>
                    <div className="admin-fillbar">
                      <div className="admin-fillbar__fill" style={{ width: `${e.fillRate}%` }} />
                    </div>
                    {e.fillRate}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ---------------- Events management ----------------
const EventsTab = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');

  const load = useCallback(() => {
    setLoading(true);
    eventService.getEvents().then((data) => setEvents(data.events)).finally(() => setLoading(false));
  }, []);

  useEffect(load, [load]);

  const openCreate = () => { setEditingEvent(null); setShowForm(true); };
  const openEdit = (event) => { setEditingEvent(event); setShowForm(true); };

  const handleSubmit = async (payload) => {
    setSubmitting(true);
    try {
      if (editingEvent) {
        await eventService.updateEvent(editingEvent._id, payload);
        setMessage('Event updated.');
      } else {
        await eventService.createEvent(payload);
        setMessage('Event created.');
      }
      setShowForm(false);
      load();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (event) => {
    if (!window.confirm(`Delete "${event.name}"? This also removes its registrations.`)) return;
    await eventService.deleteEvent(event._id);
    load();
  };

  return (
    <div>
      <div className="admin-tab-head">
        <h2 style={{ margin: 0 }}>Manage events</h2>
        <button className="btn btn-accent" onClick={openCreate}>+ Add new event</button>
      </div>
      {message && <div className="alert alert-success">{message}</div>}

      {loading ? (
        <Loader />
      ) : (
        <div className="admin-table-wrap card" style={{ padding: 4 }}>
          <table className="admin-table">
            <thead>
              <tr>
                <th>Event</th><th>Date</th><th>Category</th><th>Status</th><th>Seats</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {events.map((event) => (
                <tr key={event._id}>
                  <td>{event.name}</td>
                  <td>{formatDate(event.date)}</td>
                  <td>{event.category}</td>
                  <td><span className={`badge badge-${event.status === 'cancelled' ? 'full' : 'open'}`}>{event.status}</span></td>
                  <td>{event.availableSeats} / {event.totalSeats}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button className="btn btn-outline btn-sm" onClick={() => openEdit(event)}>Edit</button>
                      <button className="btn btn-danger btn-sm" onClick={() => handleDelete(event)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showForm && (
        <AdminEventForm
          initialEvent={editingEvent}
          submitting={submitting}
          onSubmit={handleSubmit}
          onCancel={() => setShowForm(false)}
        />
      )}
    </div>
  );
};

// ---------------- Registrations ----------------
const RegistrationsTab = () => {
  const [registrations, setRegistrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    setLoading(true);
    adminService
      .getAllRegistrations(statusFilter === 'all' ? {} : { status: statusFilter })
      .then((data) => setRegistrations(data.registrations))
      .finally(() => setLoading(false));
  }, [statusFilter]);

  return (
    <div>
      <div className="admin-tab-head">
        <h2 style={{ margin: 0 }}>All registrations</h2>
        <select className="form-select" style={{ width: 200 }} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="all">All statuses</option>
          <option value="confirmed">Confirmed</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      {loading ? (
        <Loader />
      ) : (
        <div className="admin-table-wrap card" style={{ padding: 4 }}>
          <table className="admin-table">
            <thead>
              <tr>
                <th>Reg. ID</th><th>Attendee</th><th>Event</th><th>Email</th><th>Status</th><th>Date</th>
              </tr>
            </thead>
            <tbody>
              {registrations.map((r) => (
                <tr key={r._id}>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.82rem' }}>{r.registrationId}</td>
                  <td>{r.fullName}</td>
                  <td>{r.event?.name}</td>
                  <td>{r.email}</td>
                  <td><span className={`badge badge-${r.status === 'confirmed' ? 'open' : 'full'}`}>{r.status}</span></td>
                  <td>{formatDate(r.createdAt)}</td>
                </tr>
              ))}
              {registrations.length === 0 && (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: 32, color: 'var(--text-faint)' }}>No registrations found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ---------------- Users ----------------
const UsersTab = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    adminService.getAllUsers().then((data) => setUsers(data.users)).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const toggleStatus = async (user) => {
    await adminService.updateUserStatus(user._id, !user.isActive);
    load();
  };

  const remove = async (user) => {
    if (!window.confirm(`Remove ${user.fullName}? This also deletes their registrations.`)) return;
    await adminService.deleteUser(user._id);
    load();
  };

  return (
    <div>
      <h2>Manage users</h2>
      {loading ? (
        <Loader />
      ) : (
        <div className="admin-table-wrap card" style={{ padding: 4 }}>
          <table className="admin-table">
            <thead>
              <tr><th>Name</th><th>Email</th><th>College</th><th>Status</th><th>Joined</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u._id}>
                  <td>{u.fullName}</td>
                  <td>{u.email}</td>
                  <td>{u.college || '—'}</td>
                  <td><span className={`badge badge-${u.isActive ? 'open' : 'full'}`}>{u.isActive ? 'Active' : 'Inactive'}</span></td>
                  <td>{formatDate(u.createdAt)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button className="btn btn-outline btn-sm" onClick={() => toggleStatus(u)}>
                        {u.isActive ? 'Deactivate' : 'Activate'}
                      </button>
                      <button className="btn btn-danger btn-sm" onClick={() => remove(u)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
              {users.length === 0 && (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: 32, color: 'var(--text-faint)' }}>No users yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
