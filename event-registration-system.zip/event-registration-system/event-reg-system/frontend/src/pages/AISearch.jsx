import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import eventService from '../services/eventService';
import EventCard from '../components/EventCard';
import Loader from '../components/Loader';
import './Search.css';

const SUGGESTIONS = [
  'I am interested in coding and AI',
  'music and cultural fest',
  'sports tournament this month',
  'startup and entrepreneurship',
  'robotics and engineering',
];

const AISearch = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQ = searchParams.get('q') || '';
  const [query, setQuery] = useState(initialQ);
  const [results, setResults] = useState([]);
  const [explanation, setExplanation] = useState('');
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const runSearch = useCallback((q) => {
    setLoading(true);
    setSearched(true);
    eventService
      .searchEvents(q, { includeExplanation: 'true' })
      .then((data) => {
        setResults(data.events);
        setExplanation(data.explanation || '');
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (initialQ) runSearch(initialQ);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSearchParams(query ? { q: query } : {});
    runSearch(query);
  };

  const handleSuggestion = (text) => {
    setQuery(text);
    setSearchParams({ q: text });
    runSearch(text);
  };

  return (
    <div className="container listing-page">
      <div className="search-hero">
        <span className="badge badge-ai" style={{ marginBottom: 12 }}>AI-powered</span>
        <h1>Tell us what you're into</h1>
        <p>
          Describe your interests in plain language — categories, topics, even a mood — and the
          recommender will rank the best-matching campus events for you.
        </p>

        <form onSubmit={handleSubmit} className="search-form">
          <input
            type="text"
            className="form-input"
            placeholder='e.g. "I am interested in coding and AI"'
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button className="btn btn-accent" type="submit" disabled={loading}>
            {loading ? 'Thinking…' : 'Get recommendations'}
          </button>
        </form>

        <div className="search-suggestions">
          {SUGGESTIONS.map((s) => (
            <button key={s} type="button" className="search-suggestion-chip" onClick={() => handleSuggestion(s)}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <Loader label="Matching events to your interests…" />
      ) : searched ? (
        <>
          {explanation && (
            <div className="alert alert-info" style={{ marginTop: 8 }}>
              <strong>AI insight:</strong> {explanation}
            </div>
          )}
          {results.length === 0 ? (
            <div className="empty-state">
              No matches found. Try a broader search, or <Link to="/events">browse all events</Link>.
            </div>
          ) : (
            <div className="grid-3" style={{ marginTop: 20 }}>
              {results.map((event) => (
                <EventCard key={event._id} event={event} matchReasons={event.matchReasons} />
              ))}
            </div>
          )}
        </>
      ) : (
        <div className="empty-state">Enter your interests above, or tap a suggestion to get started.</div>
      )}
    </div>
  );
};

export default AISearch;
