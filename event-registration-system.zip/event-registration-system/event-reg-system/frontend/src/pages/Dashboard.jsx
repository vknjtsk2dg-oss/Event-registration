import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import authService from '../services/authService';
import registrationService from '../services/registrationService';
import Loader from '../components/Loader';
import './Dashboard.css';

const INTEREST_OPTIONS = ['Coding', 'AI', 'Design', 'Music', 'Sports', 'Business', 'Robotics', 'Cultural'];

const Dashboard = () => {
  const { user, updateLocalUser } = useAuth();
  const [registrations, setRegistrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    fullName: user?.fullName || '', phone: user?.phone || '', college: user?.college || '',
    department: user?.department || '', studentId: user?.studentId || '', interests: user?.interests || [],
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    registrationService.getMyRegistrations().then((data) => setRegistrations(data.registrations)).finally(() => setLoading(false));
  }, []);

  const upcomingCount = registrations.filter((r) => r.status === 'confirmed').length;
  const cancelledCount = registrations.filter((r) => r.status === 'cancelled').length;

  const toggleInterest = (interest) => {
    setForm((f) => ({
      ...f,
      interests: f.interests.includes(interest)
        ? f.interests.filter((i) => i !== interest)
        : [...f.interests, interest],
    }));
  };

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setMessage('');
    try {
      const data = await authService.updateProfile(form);
      updateLocalUser(data.user);
      setMessage('Profile updated successfully.');
      setEditing(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="container listing-page">
      <span className="section-eyebrow">Your dashboard</span>
      <h1>Hi, {user?.fullName?.split(' ')[0]} 👋</h1>

      <div className="dash-stats">
        <div className="card dash-stat">
          <span className="dash-stat__value">{loading ? '—' : upcomingCount}</span>
          <span className="dash-stat__label">Active registrations</span>
        </div>
        <div className="card dash-stat">
          <span className="dash-stat__value">{loading ? '—' : cancelledCount}</span>
          <span className="dash-stat__label">Cancelled</span>
        </div>
        <div className="card dash-stat">
          <span className="dash-stat__value">{user?.interests?.length || 0}</span>
          <span className="dash-stat__label">Interests set</span>
        </div>
      </div>

      <div className="dash-grid">
        <div className="card dash-profile">
          <div className="dash-profile__head">
            <h2 style={{ margin: 0 }}>Profile</h2>
            {!editing && (
              <button className="btn btn-outline btn-sm" onClick={() => setEditing(true)}>Edit</button>
            )}
          </div>

          {message && <div className="alert alert-success">{message}</div>}
          {error && <div className="alert alert-error">{error}</div>}

          {editing ? (
            <form onSubmit={handleSave}>
              <div className="form-group">
                <label className="form-label">Full name</label>
                <input name="fullName" className="form-input" value={form.fullName} onChange={handleChange} />
              </div>
              <div className="auth-row">
                <div className="form-group">
                  <label className="form-label">Phone</label>
                  <input name="phone" className="form-input" value={form.phone} onChange={handleChange} />
                </div>
                <div className="form-group">
                  <label className="form-label">Student ID</label>
                  <input name="studentId" className="form-input" value={form.studentId} onChange={handleChange} />
                </div>
              </div>
              <div className="auth-row">
                <div className="form-group">
                  <label className="form-label">College</label>
                  <input name="college" className="form-input" value={form.college} onChange={handleChange} />
                </div>
                <div className="form-group">
                  <label className="form-label">Department</label>
                  <input name="department" className="form-input" value={form.department} onChange={handleChange} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Interests</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {INTEREST_OPTIONS.map((interest) => (
                    <button
                      type="button" key={interest} onClick={() => toggleInterest(interest)}
                      className="btn btn-sm"
                      style={{
                        background: form.interests.includes(interest) ? 'var(--violet)' : 'var(--surface-alt)',
                        color: form.interests.includes(interest) ? '#fff' : 'var(--text)',
                        border: '1px solid var(--line)',
                      }}
                    >
                      {interest}
                    </button>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button type="submit" className="btn btn-primary" disabled={saving}>
                  {saving ? 'Saving…' : 'Save changes'}
                </button>
                <button type="button" className="btn btn-outline" onClick={() => setEditing(false)}>Cancel</button>
              </div>
            </form>
          ) : (
            <dl className="dash-profile__list">
              <div><dt>Email</dt><dd>{user?.email}</dd></div>
              <div><dt>Phone</dt><dd>{user?.phone || '—'}</dd></div>
              <div><dt>College</dt><dd>{user?.college || '—'}</dd></div>
              <div><dt>Department</dt><dd>{user?.department || '—'}</dd></div>
              <div><dt>Student ID</dt><dd>{user?.studentId || '—'}</dd></div>
              <div>
                <dt>Interests</dt>
                <dd>{user?.interests?.length ? user.interests.join(', ') : '—'}</dd>
              </div>
            </dl>
          )}
        </div>

        <div className="card dash-recent">
          <h2 style={{ marginTop: 0 }}>Recent registrations</h2>
          {loading ? (
            <Loader />
          ) : registrations.length === 0 ? (
            <div className="empty-state" style={{ padding: '32px 0' }}>
              No registrations yet. <Link to="/events">Browse events</Link>
            </div>
          ) : (
            <ul className="dash-recent__list">
              {registrations.slice(0, 5).map((r) => (
                <li key={r._id}>
                  <Link to={`/events/${r.event?._id}`}>{r.event?.name}</Link>
                  <span className={`badge badge-${r.status === 'confirmed' ? 'open' : 'full'}`}>
                    {r.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
          <Link to="/my-registrations" className="btn btn-outline btn-block" style={{ marginTop: 16 }}>
            View all registrations
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
