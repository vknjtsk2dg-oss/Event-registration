import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import eventService from '../services/eventService';
import EventCard from '../components/EventCard';
import Loader from '../components/Loader';
import './Home.css';

const CATEGORY_ICONS = {
  Technology: '💻',
  Cultural: '🎭',
  Sports: '🏆',
  Business: '📈',
  default: '✨',
};

const Home = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');

  useEffect(() => {
    eventService
      .getEvents({ upcoming: 'true' })
      .then((data) => setEvents(data.events.slice(0, 6)))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const categories = Array.from(new Set(events.map((e) => e.category))).slice(0, 4);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    window.location.href = `/search?q=${encodeURIComponent(query)}`;
  };

  return (
    <div>
      <section className="home-hero">
        <div className="container home-hero__grid">
          <div>
            <span className="section-eyebrow">Campus Event Registration</span>
            <h1 className="home-hero__title">
              Find your next campus event, <span className="home-hero__title-accent">before it fills up.</span>
            </h1>
            <p className="home-hero__sub">
              Browse workshops, hackathons, fests, and more — or describe what you're into and let the
              built-in AI recommender do the searching for you.
            </p>

            <form className="home-hero__search" onSubmit={handleSearchSubmit}>
              <input
                type="text"
                className="form-input"
                placeholder='Try "I like coding and AI" or "music fest"'
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <button type="submit" className="btn btn-accent">Ask AI</button>
            </form>

            <div className="home-hero__actions">
              <Link to="/events" className="btn btn-primary">Browse all events</Link>
              <Link to="/register" className="btn btn-outline">Create an account</Link>
            </div>
          </div>

          <div className="home-hero__pass" aria-hidden="true">
            <div className="home-hero__pass-card">
              <div className="home-hero__pass-eyebrow">Live seat tracker</div>
              <div className="home-hero__pass-title">AI Workshop</div>
              <div className="home-hero__pass-bar">
                <div className="home-hero__pass-bar-fill" style={{ width: '68%' }} />
              </div>
              <div className="home-hero__pass-row">
                <span>41 / 60 seats filled</span>
                <span className="badge badge-open">Open</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {categories.length > 0 && (
        <section className="container home-categories">
          {categories.map((cat) => (
            <Link key={cat} to={`/events?category=${encodeURIComponent(cat)}`} className="home-category-chip">
              <span>{CATEGORY_ICONS[cat] || CATEGORY_ICONS.default}</span> {cat}
            </Link>
          ))}
        </section>
      )}

      <section className="container home-upcoming">
        <div className="home-upcoming__head">
          <div>
            <span className="section-eyebrow">Happening soon</span>
            <h2>Upcoming events</h2>
          </div>
          <Link to="/events" className="btn btn-outline btn-sm">View all</Link>
        </div>

        {loading ? (
          <Loader />
        ) : events.length === 0 ? (
          <div className="empty-state">No upcoming events yet. Check back soon.</div>
        ) : (
          <div className="grid-3">
            {events.map((event) => (
              <EventCard key={event._id} event={event} />
            ))}
          </div>
        )}
      </section>

      <section className="container home-how">
        <span className="section-eyebrow">How it works</span>
        <h2>Login to seat, in five steps</h2>
        <div className="home-how__grid">
          {[
            ['Sign up', 'Create your student profile in under a minute.'],
            ['Search', 'Browse listings or ask the AI recommender in plain English.'],
            ['Check seats', 'We check live availability before you fill out anything.'],
            ['Register', 'Submit the short form — name, email, phone, student ID.'],
            ['Get your pass', 'Receive a unique registration ID and digital event pass.'],
          ].map(([title, desc], i) => (
            <div key={title} className="home-how__step">
              <div className="home-how__num">{String(i + 1).padStart(2, '0')}</div>
              <h4>{title}</h4>
              <p>{desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
