import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import eventService from '../services/eventService';
import EventCard from '../components/EventCard';
import Loader from '../components/Loader';
import './Listing.css';

const Events = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const category = searchParams.get('category') || 'all';
  const sort = searchParams.get('sort') || 'date';

  useEffect(() => {
    eventService.getCategories().then((data) => setCategories(data.categories)).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    eventService
      .getEvents({ category, upcoming: 'true' })
      .then((data) => setEvents(data.events))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [category]);

  const sortedEvents = useMemo(() => {
    const list = [...events];
    if (sort === 'seats') list.sort((a, b) => b.availableSeats - a.availableSeats);
    else list.sort((a, b) => new Date(a.date) - new Date(b.date));
    return list;
  }, [events, sort]);

  const updateParam = (key, value) => {
    const next = new URLSearchParams(searchParams);
    if (value === 'all') next.delete(key);
    else next.set(key, value);
    setSearchParams(next);
  };

  return (
    <div className="container listing-page">
      <div className="listing-head">
        <div>
          <span className="section-eyebrow">Browse</span>
          <h1>All upcoming events</h1>
        </div>
        <Link to="/search" className="btn btn-accent">✨ Ask AI to recommend events</Link>
      </div>

      <div className="listing-filters">
        <select className="form-select" value={category} onChange={(e) => updateParam('category', e.target.value)}>
          <option value="all">All categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <select className="form-select" value={sort} onChange={(e) => updateParam('sort', e.target.value)}>
          <option value="date">Sort by date</option>
          <option value="seats">Sort by seats available</option>
        </select>
      </div>

      {loading ? (
        <Loader />
      ) : error ? (
        <div className="alert alert-error">{error}</div>
      ) : sortedEvents.length === 0 ? (
        <div className="empty-state">No events match this filter yet.</div>
      ) : (
        <div className="grid-3">
          {sortedEvents.map((event) => (
            <EventCard key={event._id} event={event} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Events;
