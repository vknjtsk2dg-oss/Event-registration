import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';

const Navbar = () => {
  const { isAuthenticated, isAdmin, user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setOpen(false);
    navigate('/');
  };

  const linkClass = ({ isActive }) => `navbar__link${isActive ? ' navbar__link--active' : ''}`;

  return (
    <header className="navbar">
      <div className="container navbar__inner">
        <Link to="/" className="navbar__brand" onClick={() => setOpen(false)}>
          <span className="navbar__brand-mark">EH</span>
          <span>EventHub</span>
        </Link>

        <button
          className="navbar__toggle"
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          <span />
          <span />
          <span />
        </button>

        <nav className={`navbar__nav ${open ? 'navbar__nav--open' : ''}`}>
          <NavLink to="/events" className={linkClass} onClick={() => setOpen(false)}>Events</NavLink>
          <NavLink to="/search" className={linkClass} onClick={() => setOpen(false)}>AI Search</NavLink>

          {isAuthenticated && (
            <NavLink to="/my-registrations" className={linkClass} onClick={() => setOpen(false)}>
              My Registrations
            </NavLink>
          )}
          {isAdmin && (
            <NavLink to="/admin" className={linkClass} onClick={() => setOpen(false)}>
              Admin
            </NavLink>
          )}

          <div className="navbar__divider" />

          {isAuthenticated ? (
            <div className="navbar__user">
              <NavLink to="/dashboard" className="navbar__profile" onClick={() => setOpen(false)}>
                <span className="navbar__avatar">{user?.fullName?.[0]?.toUpperCase() || 'U'}</span>
                <span>{user?.fullName?.split(' ')[0] || 'Profile'}</span>
              </NavLink>
              <button className="btn btn-outline btn-sm" onClick={handleLogout}>Log out</button>
            </div>
          ) : (
            <div className="navbar__auth">
              <Link to="/login" className="btn btn-outline btn-sm" onClick={() => setOpen(false)}>Log in</Link>
              <Link to="/register" className="btn btn-accent btn-sm" onClick={() => setOpen(false)}>Sign up</Link>
            </div>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
