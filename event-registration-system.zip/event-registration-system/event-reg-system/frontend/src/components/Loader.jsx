import React from 'react';

const Loader = ({ label = 'Loading…', fullPage = false }) => (
  <div
    style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 12,
      padding: fullPage ? '120px 24px' : '48px 24px',
      color: 'var(--text-muted)',
    }}
  >
    <div className="spinner" />
    <span style={{ fontSize: '0.85rem' }}>{label}</span>
  </div>
);

export default Loader;
