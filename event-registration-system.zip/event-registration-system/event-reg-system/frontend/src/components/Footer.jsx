import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer style={{ borderTop: '1px solid var(--line)', marginTop: 64, background: 'var(--surface)' }}>
    <div className="container" style={{
      display: 'flex', flexWrap: 'wrap', gap: 16, justifyContent: 'space-between',
      alignItems: 'center', padding: '28px 24px', fontSize: '0.85rem', color: 'var(--text-faint)',
    }}>
      <span>© {new Date().getFullYear()} EventHub — Campus Event Registration System</span>
      <div style={{ display: 'flex', gap: 20 }}>
        <Link to="/events" style={{ color: 'var(--text-muted)' }}>Events</Link>
        <Link to="/search" style={{ color: 'var(--text-muted)' }}>AI Search</Link>
        <Link to="/admin" style={{ color: 'var(--text-muted)' }}>Admin</Link>
      </div>
    </div>
  </footer>
);

export default Footer;
