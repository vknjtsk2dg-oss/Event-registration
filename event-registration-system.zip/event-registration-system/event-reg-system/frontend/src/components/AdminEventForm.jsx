import React, { useState, useEffect } from 'react';

const CATEGORY_OPTIONS = ['Technology', 'Cultural', 'Sports', 'Business', 'Science', 'Arts', 'Career', 'Other'];

const emptyForm = {
  name: '', description: '', category: 'Technology', tags: '', date: '', time: '',
  venue: '', totalSeats: 50, imageUrl: '', organizer: '', status: 'upcoming',
};

const toDateInputValue = (d) => (d ? new Date(d).toISOString().slice(0, 10) : '');

const AdminEventForm = ({ initialEvent, onSubmit, onCancel, submitting }) => {
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');

  useEffect(() => {
    if (initialEvent) {
      setForm({
        name: initialEvent.name || '',
        description: initialEvent.description || '',
        category: initialEvent.category || 'Technology',
        tags: (initialEvent.tags || []).join(', '),
        date: toDateInputValue(initialEvent.date),
        time: initialEvent.time || '',
        venue: initialEvent.venue || '',
        totalSeats: initialEvent.totalSeats || 50,
        imageUrl: initialEvent.imageUrl || '',
        organizer: initialEvent.organizer || '',
        status: initialEvent.status || 'upcoming',
      });
    } else {
      setForm(emptyForm);
    }
  }, [initialEvent]);

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await onSubmit({
        ...form,
        totalSeats: Number(form.totalSeats),
        tags: form.tags.split(',').map((t) => t.trim()).filter(Boolean),
      });
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="admin-modal-overlay">
      <div className="card admin-modal">
        <h2>{initialEvent ? 'Edit event' : 'Create new event'}</h2>
        {error && <div className="alert alert-error">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Event name</label>
            <input name="name" className="form-input" required value={form.name} onChange={handleChange} />
          </div>
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea name="description" className="form-textarea" rows={3} required
              value={form.description} onChange={handleChange} />
          </div>
          <div className="auth-row">
            <div className="form-group">
              <label className="form-label">Category</label>
              <select name="category" className="form-select" value={form.category} onChange={handleChange}>
                {CATEGORY_OPTIONS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Tags (comma separated)</label>
              <input name="tags" className="form-input" placeholder="ai, workshop, python"
                value={form.tags} onChange={handleChange} />
            </div>
          </div>
          <div className="auth-row">
            <div className="form-group">
              <label className="form-label">Date</label>
              <input name="date" type="date" className="form-input" required value={form.date} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label className="form-label">Time</label>
              <input name="time" className="form-input" required placeholder="10:00 AM" value={form.time} onChange={handleChange} />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Venue</label>
            <input name="venue" className="form-input" required value={form.venue} onChange={handleChange} />
          </div>
          <div className="auth-row">
            <div className="form-group">
              <label className="form-label">Total seats</label>
              <input name="totalSeats" type="number" min={1} className="form-input" required
                value={form.totalSeats} onChange={handleChange} />
              {initialEvent && (
                <p className="form-hint">Changing this adjusts available seats by the same amount.</p>
              )}
            </div>
            <div className="form-group">
              <label className="form-label">Status</label>
              <select name="status" className="form-select" value={form.status} onChange={handleChange}>
                <option value="upcoming">Upcoming</option>
                <option value="ongoing">Ongoing</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Image URL (optional)</label>
            <input name="imageUrl" className="form-input" placeholder="https://…"
              value={form.imageUrl} onChange={handleChange} />
          </div>
          <div className="form-group">
            <label className="form-label">Organizer</label>
            <input name="organizer" className="form-input" placeholder="Campus Events Committee"
              value={form.organizer} onChange={handleChange} />
          </div>

          <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Saving…' : initialEvent ? 'Save changes' : 'Create event'}
            </button>
            <button type="button" className="btn btn-outline" onClick={onCancel}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminEventForm;
