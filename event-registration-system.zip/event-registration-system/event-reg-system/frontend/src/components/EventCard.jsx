import React from 'react';
import { Link } from 'react-router-dom';
import SeatBadge from './SeatBadge';
import './EventCard.css';

const formatDate = (dateStr) =>
  new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

const EventCard = ({ event, matchReasons }) => {
  const { _id, name, description, category, date, time, venue, availableSeats, totalSeats, imageUrl } = event;

  return (
    <Link to={`/events/${_id}`} className="event-card">
      <div className="event-card__media" style={{ backgroundImage: `url(${imageUrl || ''})` }}>
        {!imageUrl && <span className="event-card__media-fallback">{category?.[0] || 'E'}</span>}
        <span className="event-card__category">{category}</span>
      </div>
      <div className="event-card__body">
        <div className="event-card__date">{formatDate(date)} · {time}</div>
        <h3 className="event-card__title">{name}</h3>
        <p className="event-card__desc">{description}</p>
        <div className="event-card__meta">
          <span className="event-card__venue">📍 {venue}</span>
          <SeatBadge availableSeats={availableSeats} totalSeats={totalSeats} />
        </div>
        {matchReasons && matchReasons.length > 0 && (
          <div className="event-card__match">
            <span className="badge badge-ai">AI match</span>
            <span>{matchReasons.slice(0, 3).join(', ')}</span>
          </div>
        )}
      </div>
    </Link>
  );
};

export default EventCard;
