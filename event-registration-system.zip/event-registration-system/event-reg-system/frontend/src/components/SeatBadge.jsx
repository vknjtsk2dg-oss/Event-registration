import React from 'react';

export const seatState = (availableSeats, totalSeats) => {
  if (availableSeats <= 0) return 'full';
  if (totalSeats > 0 && availableSeats / totalSeats <= 0.15) return 'low';
  return 'open';
};

const LABELS = {
  open: 'Seats open',
  low: 'Filling fast',
  full: 'Sold out',
};

const SeatBadge = ({ availableSeats, totalSeats }) => {
  const state = seatState(availableSeats, totalSeats);
  return (
    <span className={`badge badge-${state}`}>
      {LABELS[state]}
      {state !== 'full' && ` · ${availableSeats} left`}
    </span>
  );
};

export default SeatBadge;
