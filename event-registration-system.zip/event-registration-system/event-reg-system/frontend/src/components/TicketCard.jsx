import React from 'react';
import './TicketCard.css';

const formatDate = (dateStr) =>
  new Date(dateStr).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });

// Generates a simple deterministic "barcode" pattern from the registration ID
// purely for visual flavor (not a real scannable code).
const BarcodePattern = ({ seed }) => {
  const bars = [];
  let x = 0;
  for (let i = 0; i < seed.length; i++) {
    const code = seed.charCodeAt(i);
    const width = 1 + (code % 3);
    bars.push(<rect key={i} x={x} y={0} width={width} height={36} fill={i % 2 === 0 ? 'var(--ink)' : 'transparent'} />);
    x += width + 1;
  }
  return (
    <svg width="100%" height="36" viewBox={`0 0 ${x} 36`} preserveAspectRatio="none" aria-hidden="true">
      {bars}
    </svg>
  );
};

const TicketCard = ({ registration, event, status = 'confirmed' }) => {
  const isCancelled = status === 'cancelled';

  return (
    <div className={`ticket ${isCancelled ? 'ticket--cancelled' : ''}`}>
      <div className="ticket__main">
        <div className="ticket__eyebrow">Campus Event Pass</div>
        <h3 className="ticket__event-name">{event?.name}</h3>
        <div className="ticket__row">
          <div>
            <span className="ticket__label">Date</span>
            <span className="ticket__value">{event?.date ? formatDate(event.date) : '—'}</span>
          </div>
          <div>
            <span className="ticket__label">Time</span>
            <span className="ticket__value">{event?.time || '—'}</span>
          </div>
        </div>
        <div className="ticket__row">
          <div>
            <span className="ticket__label">Venue</span>
            <span className="ticket__value">{event?.venue || '—'}</span>
          </div>
        </div>
        <div className="ticket__row">
          <div>
            <span className="ticket__label">Attendee</span>
            <span className="ticket__value">{registration?.fullName}</span>
          </div>
          <div>
            <span className="ticket__label">Student ID</span>
            <span className="ticket__value">{registration?.studentId}</span>
          </div>
        </div>
      </div>

      <div className="ticket__stub">
        <span className="ticket__stub-label">Registration ID</span>
        <span className="ticket__stub-id">{registration?.registrationId}</span>
        <BarcodePattern seed={registration?.registrationId || 'EVENTHUB'} />
        <span className={`ticket__status ticket__status--${status}`}>
          {isCancelled ? 'Cancelled' : 'Confirmed'}
        </span>
      </div>
    </div>
  );
};

export default TicketCard;
