import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import authService from '../services/authService';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('eh_user');
    return stored ? JSON.parse(stored) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('eh_token'));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Revalidate the session on load so stale/expired tokens are cleared
    const bootstrap = async () => {
      if (token) {
        try {
          const data = await authService.getProfile();
          setUser(data.user);
          localStorage.setItem('eh_user', JSON.stringify(data.user));
        } catch (err) {
          setUser(null);
          setToken(null);
          localStorage.removeItem('eh_token');
          localStorage.removeItem('eh_user');
        }
      }
      setLoading(false);
    };
    bootstrap();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = useCallback(async (credentials) => {
    const data = await authService.login(credentials);
    setUser(data.user);
    setToken(data.token);
    localStorage.setItem('eh_token', data.token);
    localStorage.setItem('eh_user', JSON.stringify(data.user));
    return data.user;
  }, []);

  const register = useCallback(async (payload) => {
    const data = await authService.register(payload);
    setUser(data.user);
    setToken(data.token);
    localStorage.setItem('eh_token', data.token);
    localStorage.setItem('eh_user', JSON.stringify(data.user));
    return data.user;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('eh_token');
    localStorage.removeItem('eh_user');
  }, []);

  const updateLocalUser = useCallback((updatedUser) => {
    setUser(updatedUser);
    localStorage.setItem('eh_user', JSON.stringify(updatedUser));
  }, []);

  const value = {
    user,
    token,
    isAuthenticated: !!token && !!user,
    isAdmin: user?.role === 'admin',
    loading,
    login,
    register,
    logout,
    updateLocalUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};

export default AuthContext;
