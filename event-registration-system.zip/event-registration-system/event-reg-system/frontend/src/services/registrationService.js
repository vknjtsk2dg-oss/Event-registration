import api from './api';

const registerForEvent = (data) => api.post('/registrations', data).then((res) => res.data);
const getRegistrationById = (id) => api.get(`/registrations/${id}`).then((res) => res.data);
const getMyRegistrations = () => api.get('/registrations/my').then((res) => res.data);
const cancelRegistration = (id) => api.put(`/registrations/${id}/cancel`).then((res) => res.data);

const registrationService = {
  registerForEvent,
  getRegistrationById,
  getMyRegistrations,
  cancelRegistration,
};
export default registrationService;
