import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
});

// Attach the JWT (if present) to every outgoing request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('eh_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Normalize error messages so components can just read err.message
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const message =
      error.response?.data?.message || error.message || 'Something went wrong. Please try again.';

    if (error.response?.status === 401) {
      // Token expired/invalid - clear local session.
      // (We don't force-redirect here; ProtectedRoute handles that.)
      localStorage.removeItem('eh_token');
      localStorage.removeItem('eh_user');
    }

    return Promise.reject({ ...error, message });
  }
);

export default api;
