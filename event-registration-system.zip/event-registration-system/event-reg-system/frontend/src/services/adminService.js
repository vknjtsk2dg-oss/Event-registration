import api from './api';

const getDashboardStats = () => api.get('/admin/stats').then((res) => res.data);
const getEventStats = () => api.get('/admin/events/stats').then((res) => res.data);
const getAllRegistrations = (params = {}) =>
  api.get('/admin/registrations', { params }).then((res) => res.data);
const getAllUsers = () => api.get('/admin/users').then((res) => res.data);
const updateUserStatus = (id, isActive) =>
  api.put(`/admin/users/${id}/status`, { isActive }).then((res) => res.data);
const deleteUser = (id) => api.delete(`/admin/users/${id}`).then((res) => res.data);

const adminService = {
  getDashboardStats,
  getEventStats,
  getAllRegistrations,
  getAllUsers,
  updateUserStatus,
  deleteUser,
};
export default adminService;
