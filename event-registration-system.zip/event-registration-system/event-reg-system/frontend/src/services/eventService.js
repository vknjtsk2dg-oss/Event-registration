import api from './api';

const getEvents = (params = {}) => api.get('/events', { params }).then((res) => res.data);
const getEventById = (id) => api.get(`/events/${id}`).then((res) => res.data);
const checkAvailability = (id) => api.get(`/events/${id}/availability`).then((res) => res.data);
const searchEvents = (q, params = {}) =>
  api.get('/events/search/ai', { params: { q, ...params } }).then((res) => res.data);
const getCategories = () => api.get('/events/meta/categories').then((res) => res.data);

const createEvent = (data) => api.post('/events', data).then((res) => res.data);
const updateEvent = (id, data) => api.put(`/events/${id}`, data).then((res) => res.data);
const deleteEvent = (id) => api.delete(`/events/${id}`).then((res) => res.data);

const eventService = {
  getEvents,
  getEventById,
  checkAvailability,
  searchEvents,
  getCategories,
  createEvent,
  updateEvent,
  deleteEvent,
};
export default eventService;
