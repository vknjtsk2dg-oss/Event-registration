import api from './api';

const register = (data) => api.post('/auth/register', data).then((res) => res.data);
const login = (data) => api.post('/auth/login', data).then((res) => res.data);
const getProfile = () => api.get('/auth/profile').then((res) => res.data);
const updateProfile = (data) => api.put('/auth/profile', data).then((res) => res.data);

const authService = { register, login, getProfile, updateProfile };
export default authService;
