import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import { ProtectedRoute, AdminRoute } from './components/ProtectedRoute';

import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Events from './pages/Events';
import AISearch from './pages/AISearch';
import EventDetails from './pages/EventDetails';
import RegistrationForm from './pages/RegistrationForm';
import Confirmation from './pages/Confirmation';
import MyRegistrations from './pages/MyRegistrations';
import Dashboard from './pages/Dashboard';
import AdminDashboard from './pages/AdminDashboard';

import './styles/theme.css';

const NotFound = () => (
  <div className="container listing-page" style={{ textAlign: 'center', padding: '100px 24px' }}>
    <h1>404</h1>
    <p>That page doesn't exist.</p>
  </div>
);

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
          <Navbar />
          <main style={{ flex: 1 }}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/events" element={<Events />} />
              <Route path="/search" element={<AISearch />} />
              <Route path="/events/:id" element={<EventDetails />} />

              <Route
                path="/events/:id/register"
                element={
                  <ProtectedRoute>
                    <RegistrationForm />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/confirmation/:id"
                element={
                  <ProtectedRoute>
                    <Confirmation />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-registrations"
                element={
                  <ProtectedRoute>
                    <MyRegistrations />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin"
                element={
                  <AdminRoute>
                    <AdminDashboard />
                  </AdminRoute>
                }
              />

              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
